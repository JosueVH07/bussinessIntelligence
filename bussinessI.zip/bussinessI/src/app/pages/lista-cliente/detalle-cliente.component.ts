import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detalle-cliente',
  templateUrl: './detalle-cliente.component.html',
  styleUrls: ['./detalle-cliente.component.css']
})
export class DetalleClienteComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
