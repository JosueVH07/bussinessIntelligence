import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editar-rol',
  templateUrl: './editar-rol.component.html',
  styleUrls: ['./editar-rol.component.css']
})
export class EditarRolComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
