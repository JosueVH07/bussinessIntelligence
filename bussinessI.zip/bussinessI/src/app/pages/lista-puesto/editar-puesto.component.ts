import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editar-puesto',
  templateUrl: './editar-puesto.component.html',
  styleUrls: ['./editar-puesto.component.css']
})
export class EditarPuestoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
