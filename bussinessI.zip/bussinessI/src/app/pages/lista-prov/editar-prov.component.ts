import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-editar-prov',
  templateUrl: './editar-prov.component.html',
  styleUrls: ['./editar-prov.component.css']
})
export class EditarProvComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
