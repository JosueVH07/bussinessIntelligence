import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detalle-prov',
  templateUrl: './detalle-prov.component.html',
  styleUrls: ['./detalle-prov.component.css']
})
export class DetalleProvComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
