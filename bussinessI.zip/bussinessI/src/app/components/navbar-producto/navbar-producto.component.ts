import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbar-producto',
  templateUrl: './navbar-producto.component.html',
  styleUrls: ['./navbar-producto.component.css']
})
export class NavbarProductoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
