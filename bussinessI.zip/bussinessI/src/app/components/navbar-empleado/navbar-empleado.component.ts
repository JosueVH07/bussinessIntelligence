import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbar-empleado',
  templateUrl: './navbar-empleado.component.html',
  styleUrls: ['./navbar-empleado.component.css']
})
export class NavbarEmpleadoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
