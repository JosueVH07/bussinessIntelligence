import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbar-clientes',
  templateUrl: './navbar-clientes.component.html',
  styleUrls: ['./navbar-clientes.component.css']
})
export class NavbarClientesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
