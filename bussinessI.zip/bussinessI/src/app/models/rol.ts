export class Rol {
    idrol: number;
    nombre: string;
    idusuario: number;

    constructor(idrol:number ,nombre: string, idusuario: number){
        this.idrol=idrol;
        this.nombre=nombre;
        this.idusuario=idusuario;
    }
}
