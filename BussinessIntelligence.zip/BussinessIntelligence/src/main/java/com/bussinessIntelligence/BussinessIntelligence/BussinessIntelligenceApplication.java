package com.bussinessIntelligence.BussinessIntelligence;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BussinessIntelligenceApplication {

	public static void main(String[] args) {
		SpringApplication.run(BussinessIntelligenceApplication.class, args);
	}

}
